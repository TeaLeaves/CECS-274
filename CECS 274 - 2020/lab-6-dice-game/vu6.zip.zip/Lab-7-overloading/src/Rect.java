public class Rect {
    //instance variables
    private int width;
    private  int height;

    //constructor

    /**
     * given no param
     */
    public Rect(){
        width = 0;
        height = 0;
    }

    //override constructors

    /**
     * @param value: pass on to as height and width value
     */
    public Rect(int value){
        //make sure that value is valid
        if(value>=0) {
            width = value;
            height = value;
        } else{
            width = 0;
            height = 0;
        }
    }

    /**
     * @param widthValue: value given to width
     * @param heightValue: value given to height
     */
    public Rect(int widthValue, int heightValue){
        //make sure widthValue is valid
        if(widthValue>=0) {
            width = widthValue;
        } else{
            width = 0;
        }
        //make sure heightValue is valid
        if(heightValue>=0) {
            height = heightValue;
        } else{
            height = 0;
        }
    }

    /**
     * take the width and height from this rectangle and copy it over
     * @param rectangle: has width and height
     */
    public Rect(Rect rectangle){
        width = rectangle.getWidth();
        height = rectangle.getHeight();
    }

    //methods

    /**
     * get the width of the rectangle
     * @return the width value
     */
    public int getWidth(){
        return this.width;
    }

    /**
     * get the height of the rectangle
     * @return the height value
     */
    public int getHeight(){
        return this.height;
    }

    /**
     * check if two rectangles have the same values for height and width
     * @param rectangle: the rectangle being compared with
     * @return: true if width and height are same, and false if not
     */
    public boolean equals(Rect rectangle){
        if(this.height == rectangle.getHeight() && this.width == rectangle.getWidth()){
            return true;
        } else{
            return false;
        }
    }


    public int compareTo(Rect rectangle){
        //if heights are the same
        if(this.height == rectangle.getHeight()){
            //compare the width
        }
    }

    public void scale(int scale){

    }
}
